#include <stdio.h>
#include <string.h>
const int N = 100005, M = (N >> 3) + 5, BASE = 100000000;
char a[N], b[N];
int x[M], y[M];
inline unsigned abs(const int &n) { return n < 0 ? -n : n; }
inline int max(const int &x, const int &y) { return x > y ? x : y; }
inline void init(const char *a, int *x, int &la)
{
    if (*a ^ '-')
    {
        la = strlen(a);
        *x = la + 7 >> 3;
        register int i = 0, j, k;
        for (j = la - (*x - 1 << 3), k = *x; i < j; ++i)
            x[k] = (x[k] << 3) + (x[k] << 1) + (a[i] ^ '0');
        for (j = *x - 1; i < la; --j)
        {
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
        }
    }
    else
    {
        la = strlen(a + 1);
        *x = -(la + 7 >> 3);
        register int i = 1, j, k;
        for (j = la - (-*x - 1 << 3), k = -*x; i <= j; ++i)
            x[k] = (x[k] << 3) + (x[k] << 1) + (a[i] ^ '0');
        for (j = -*x - 1; i <= la; --j)
        {
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
        }
    }
}
inline bool issml(const int *a, const int &la, const int *b, const int &lb)
{
    if (la > lb)
        return 0;
    else if (la < lb)
        return 1;
    else
    {
        for (register int i = abs(*a); i; --i)
            if (a[i] ^ b[i])
            {
                if (a[i] < b[i])
                    return 1;
                else
                    return 0;
            }
    }
    return 0;
}
inline void hpls(int *a, const int *b)
{
    register int len = max(abs(*a), abs(*b));
    for (register int i = 1; i <= len; ++i)
    {
        a[i] += b[i];
        if (a[i] >= BASE)
        {
            ++a[i + 1];
            a[i] -= BASE;
        }
    }
    if (a[len + 1])
        ++len;
    *a = (*a < 0 ? -1 : 1) * len;
}
inline void hsub(int *a, const int *b)
{
    register int len = abs(*a);
    for (register int i = 1; i <= len; ++i)
    {
        a[i] -= b[i];
        if (a[i] < 0)
        {
            --a[i + 1];
            a[i] += BASE;
        }
    }
    while (len > 1 && !a[len])
        --len;
    *a = (*a < 0 ? -1 : 1) * len;
}
inline void prn(const int *n, const char &c = 0)
{
    if (*n < 0)
        putchar('-');
    register unsigned p = abs(*n);
    printf("%d", n[p--]);
    while (p)
        printf("%08d", n[p--]);
    if (c)
        putchar(c);
}
int main(int argc, char **argv)
{
    if (argc == 3)
    {
        freopen(argv[0], "r", stdin);
        freopen(argv[1], "w", stdout);
    }
    scanf("%[^+]+%s", a, b);
    static int la, lb;
    init(a, x, la);
    init(b, y, lb);
    if (*x > 0 ^ *y > 0)
    {
        if (issml(x, la, y, lb))
        {
            hsub(y, x);
            prn(y, '\n');
        }
        else
        {
            hsub(x, y);
            prn(x, '\n');
        }
    }
    else
    {
        hpls(x, y);
        prn(x, '\n');
    }
    return 0;
}
