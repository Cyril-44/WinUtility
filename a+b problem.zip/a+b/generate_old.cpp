#include "../randext.h"
#include <iostream>
using std::cout;
using std::endl;
char buf[1 << 8];
int main()
{
    FILE *f = nullptr;
    for (int i = 1; i <= 10; i++)
    {
        printf("Generating A+B Problem Test Data No.%d...", i);
        sprintf(buf, "%d.in", i);
        f = fopen(buf, "w");
        int a = randL(-1e4, 10000), b = randL(-1e4, 1e4);
        fprintf(f, "%d+%d", a, b);
        fclose(f);
        sprintf(buf, "%d.out", i);
        f = fopen(buf, "w");
        fprintf(f, "%d\n", a + b);
        fclose(f);
        puts("Done");
    }
    for (int i = 11; i <= 20; i++)
    {
        printf("Generating A+B Problem Test Data No.%d...", i);
        sprintf(buf, "%d.in", i);
        f = fopen(buf, "w");
        int a = randL(-1e9, 1e9), b = randL(-1e9, 1e9);
        while (abs(a + b) <= (int)2e4)
            a = randL(-1e9, 1e9), b = randL(-1e9, 1e9);
        fprintf(f, "%d+%d", a, b);
        fclose(f);
        sprintf(buf, "%d.out", i);
        f = fopen(buf, "w");
        fprintf(f, "%d\n", a + b);
        fclose(f);
        puts("Done");
    }
    for (int i = 21; i <= 40; i++)
    {
        printf("Generating A+B Problem Test Data No.%d...", i);
        sprintf(buf, "%d.in", i);
        f = fopen(buf, "w");
        long long a = randL(-1e18, 1e18), b = randL(-1e18, 1e18);
        while (llabs(a + b) <= (long long)2e9)
            a = randL(-1e18, 1e18), b = randL(-1e18, 1e18);
        fprintf(f, "%lld+%lld", a, b);
        fclose(f);
        sprintf(buf, "%d.out", i);
        f = fopen(buf, "w");
        fprintf(f, "%lld\n", a + b);
        fclose(f);
        puts("Done");
    }
    for (int i = 41; i <= 70; i++)
    {
        printf("Generating A+B Problem Test Data No.%d...", i);
        sprintf(buf, "%d.in", i);
        f = fopen(buf, "w");
        std::string a = randS("[1-9][0-9]{100, 999}"), b = randS("[1-9][0-9]{100, 999}");
        fprintf(f, "%s+%s", a.c_str(), b.c_str());
        fclose(f);
        sprintf(buf, "%d.out", i);
        f = fopen(buf, "w");
        for (auto &i : a)
            i ^= '0';
        for (auto &i : b)
            i ^= '0';
        std::reverse(a.begin(), a.end());
        std::reverse(b.begin(), b.end());
        a.resize(std::max(a.size(), b.size()) + 1);
        b.resize(a.size());
        for (int i = 0; i < a.size() - 1; i++)
            a[i] = a[i] + b[i], a[i + 1] += a[i] / 10, a[i] %= 10;
        while (a[a.size() - 1] == 0)
            a.resize(a.size() - 1);
        for (auto &i : a)
            i |= '0';
        std::reverse(a.begin(), a.end());
        fprintf(f, "%s\n", a.c_str());
        fclose(f);
        puts("Done");
    }
    for (int i = 71; i <= 100; i++)
    {
        printf("Generating A+B Problem Test Data No.%d...", i);
        sprintf(buf, "%d.in", i);
        f = fopen(buf, "w");
        std::string a = randS("[1-9][0-9]{50000,99999}"), b = randS("[1-9][0-9]{50000,99999}");
        fprintf(f, "%s+%s", a.c_str(), b.c_str());
        fclose(f);
        sprintf(buf, "%d.out", i);
        f = fopen(buf, "w");
        for (auto &i : a)
            i ^= '0';
        for (auto &i : b)
            i ^= '0';
        std::reverse(a.begin(), a.end());
        std::reverse(b.begin(), b.end());
        a.resize(std::max(a.size(), b.size()) + 1);
        b.resize(a.size());
        for (int i = 0; i < a.size() - 1; i++)
            a[i] = a[i] + b[i], a[i + 1] += a[i] / 10, a[i] %= 10;
        while (a[a.size() - 1] == 0)
            a.resize(a.size() - 1);
        for (auto &i : a)
            i |= '0';
        std::reverse(a.begin(), a.end());
        fprintf(f, "%s\n", a.c_str());
        fclose(f);
        puts("Done");
    }
    return 0;
}