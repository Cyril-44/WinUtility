#include <stdio.h>
#include <stdlib.h>
#include "testlib.h"
FILE *deb = fopen("debug_cmd.txt", "w");
inline void generate(const int &id, const char *rules)
{
    static FILE *f;
    f = fopen(("A+B_Data/a+b_" + vtos(id) + ".in").c_str(), "w");
    fprintf(f, rnd.next(rules).c_str());
    fclose(f);
    fprintf(deb, "%s\n",
            ((std::string) "./a+b.o" + " " +
             "A+B_Data/a+b_" + vtos(id) + ".in" + " " +
             "A+B_Data/a+b_" + vtos(id) + ".out")
                .c_str());
    system(((std::string) "./a+b.o" + " " +
            "A+B_Data/a+b_" + vtos(id) + ".in" + " " +
            "A+B_Data/a+b_" + vtos(id) + ".out")
               .c_str());
}
inline void generate_samples(const int &id, const char *rules)
{
    static FILE *f;
    f = fopen(("A+B_Samples/a+b_" + vtos(id) + ".in").c_str(), "w");
    fprintf(f, rnd.next(rules).c_str());
    fclose(f);
    fprintf(deb, "%s\n",
            ((std::string) "./a+b.o" + " " +
             "A+B_Samples/a+b_" + vtos(id) + ".in" + " " +
             "A+B_Samples/a+b_" + vtos(id) + ".out")
                .c_str());
    system(((std::string) "./a+b.o" + " " +
            "A+B_Samples/a+b_" + vtos(id) + ".in" + " " +
            "A+B_Samples/a+b_" + vtos(id) + ".out")
               .c_str());
}
int main(int argc, char *argv[])
{
    registerGen(argc, argv, 1);
    freopen("debug.txt", "wt", stderr);
    puts("A+B Test Data Generater\n\tWrote by HardsoftCyril On 10th Jan. 2023\n");

    printf("Generating data No.1~10   (-1e4 < a,b < 1e4)           ... ");
    fflush(stdout);
    for (register int i = 1; i <= 10; i++)
        generate(i, "-?[1-9][0-9]{0,3}+-?[1-9][0-9]{0,3}\n");
    generate_samples(1, "-?[1-9][0-9]{0,3}+-?[1-9][0-9]{0,3}\n");
    puts("Done.");

    printf("Generating data No.11~20  (-1e9 < a,b < 1e9)           ... ");
    fflush(stdout);
    for (register int i = 11; i <= 20; i++)
        generate(i, "-?[1-9][0-9]{6,8}+-?[1-9][0-9]{6,8}\n");
    generate_samples(2, "-?[1-9][0-9]{6,8}+-?[1-9][0-9]{6,8}\n");
    puts("Done.");

    printf("Generating data No.21~30  (-1e18 < a,b < 1e18)         ... ");
    fflush(stdout);
    for (register int i = 21; i <= 30; i++)
        generate(i, "-?[1-9][0-9]{15, 17}+-?[1-9][0-9]{15, 17}\n");
    generate_samples(3, "-?[1-9][0-9]{15, 17}+-?[1-9][0-9]{15, 17}\n");
    puts("Done.");

    printf("Generating data No.31~50  (-1e1000 < a,b < 1e1000)     ... ");
    fflush(stdout);
    for (register int i = 31; i <= 50; i++)
        generate(i, "-?[1-9][0-9]{888, 999}+-?[1-9][0-9]{888, 999}\n");
    generate_samples(4, "-?[1-9][0-9]{888, 999}+-?[1-9][0-9]{888, 999}\n");
    puts("Done.");

    printf("Generating data No.51~100 (-1e100000 < a,b < 1e100000) ... ");
    fflush(stdout);
    for (register int i = 51; i <= 100; i++)
        generate(i, "-?[1-9][0-9]{88888, 99999}+-?[1-9][0-9]{88888, 99999}\n");
    generate_samples(5, "-?[1-9][0-9]{88888, 99999}+-?[1-9][0-9]{88888, 99999}\n");
    puts("Done.");

    return 0;
}