#include <stdio.h>
typedef long long i64;
const int N = 100005, M = (N / 18) + 5;
const i64 BASE = 1e18;
#define max(x, y) ((x) > (y) ? (x) : (y))
#define abs(n) ((n) < 0 ? -(n) : (n))
inline void init(const char *a, i64 *x, const i64 &la)
{
    if (*a ^ '-')
    {
        *x = (la + 17) / 18;
        register int i = 0, j, k;
        for (j = la - (*x - 1) * 18, k = *x; i < j; ++i)
            x[k] = (x[k] << 3) + (x[k] << 1) + (a[i] ^ '0');
        for (j = *x - 1; i < la; --j)
        { // 18 Times
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
        }
    }
    else
    {
        *x = -((la + 17) / 18);
        register int i = 1, j, k;
        for (j = la - (-*x - 1) * 18, k = -*x; i <= j; ++i)
            x[k] = (x[k] << 3) + (x[k] << 1) + (a[i] ^ '0');
        for (j = -*x - 1; i <= la; --j)
        { // 18 Times
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
            x[j] = (x[j] << 3) + (x[j] << 1) + (a[i] ^ '0'), ++i;
        }
    }
}
inline bool issml(const i64 *a, const i64 &la, const i64 *b, const i64 &lb)
{
    if (la > lb)
        return 0;
    else if (la < lb)
        return 1;
    else
    {
        for (register unsigned i = abs(*a); i; --i)
            if (a[i] ^ b[i])
            {
                if (a[i] < b[i])
                    return 1;
                else
                    return 0;
            }
    }
    return 0;
}
inline void hpls(i64 *a, const i64 *b)
{
    register unsigned len = max(abs(*a), abs(*b));
    for (register unsigned i = 1; i <= len; ++i)
    {
        a[i] += b[i];
        if (a[i] >= BASE)
        {
            ++a[i + 1];
            a[i] -= BASE;
        }
    }
    if (a[len + 1])
        ++len;
    *a = (*a < 0 ? -1ll : 1ll) * len;
}
inline void hsub(i64 *a, const i64 *b)
{
    register unsigned len = abs(*a);
    for (register unsigned i = 1; i <= len; ++i)
    {
        a[i] -= b[i];
        if (a[i] < 0)
        {
            --a[i + 1];
            a[i] += BASE;
        }
    }
    while (len > 1 && !a[len])
        --len;
    *a = (*a < 0 ? -1ll : 1ll) * len;
}
inline void prn(const i64 *n, const char &c = 0)
{
    if (*n < 0)
        putchar('-');
    register unsigned p = abs(*n);
    // printf("%u ", p);
    printf("%lld", n[p--]);
    while (p)
        printf("%018lld", n[p--]);
    if (c)
        putchar(c);
}
int main(int argc, char **argv)
{
    static char a[N], b[N];
    static i64 x[M], y[M];
    static int la, lb;
    if (argc == 3)
    {
        fprintf(stderr, "%llx %llx\n",
                (unsigned long long)freopen(argv[1], "r", stdin),
                (unsigned long long)freopen(argv[2], "w", stdout));
    }

    *a = getchar();
    if (*a ^ '-')
    {
        while ((a[++la] = getchar()) ^ '+')
            ;
        a[la] = '\0';
    }
    else
    {
        while ((a[++la] = getchar()) ^ '+')
            ;
        a[la--] = '\0';
    }

    *b = getchar();
    if (*b ^ '-')
    {
        while ((b[++lb] = getchar()) ^ '\n')
            ;
        b[lb] = '\0';
    }
    else
    {
        while ((b[++lb] = getchar()) ^ '\n')
            ;
        b[lb--] = '\0';
    }

    init(a, x, la);
    init(b, y, lb);

    // prn(x, ' '), prn(y, '\n');

    if (*x > 0 ^ *y > 0)
    {
        if (issml(x, la, y, lb))
        {
            hsub(y, x);
            prn(y, '\n');
        }
        else
        {
            hsub(x, y);
            prn(x, '\n');
        }
    }
    else
    {
        hpls(x, y);
        prn(x, '\n');
    }

    return 0;
}
