#include <stdio.h>
const int N = 100005;
char s[N << 2];
int a[N], b[N];
int main()
{
    scanf("%s", s);
    int i, f = 1;
    if (s[0] == '-')
        f = 0;
    for (i = 1; f && s[i]; i++)
        if (s[i] == '+')
        {
            if (s[i + 1] == '-')
                f = 0;
        }
    if (f)
    {
        for (i = 0; s[i] ^ '+'; i++)
            a[++a[0]] = s[i] ^ '0';
        for (i++; s[i]; i++)
            b[++b[0]] = s[i] ^ '0';
        for (i = 1; i <= a[0] >> 1; i++)
            a[i] ^= a[a[0] - i + 1] ^= a[i] ^= a[a[0] - i + 1];
        for (i = 1; i <= b[0] >> 1; i++)
            b[i] ^= b[b[0] - i + 1] ^= b[i] ^= b[b[0] - i + 1];
        if (b[0] > a[0])
            a[0] = b[0];
        for (i = 1; i <= a[0]; i++)
            a[i] = a[i] + b[i], a[i + 1] += a[i] / 10, a[i] %= 10;
        if (a[a[0] + 1])
            ++a[0];
        for (i = a[0]; i; i--)
            putchar(a[i] | '0');
        putchar('\n');
    }
    else
    {
        long long a, b;
        sscanf(s, "%lld+%lld", &a, &b);
        printf("%lld\n", a + b);
    }
    return 0;
}